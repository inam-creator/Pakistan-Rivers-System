package pk.pakistanrivers.system

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

data class River(val name: String, val source: String, val outlet: String, val description: String)

private val rivers = listOf(
    River("Indus", "Tibetan Plateau", "Arabian Sea", "Principal river system and backbone of the Indus Basin."),
    River("Jhelum", "Verinag Spring, Kashmir", "Chenab", "Major western tributary of the Chenab."),
    River("Chenab", "Chandra and Bhaga rivers", "Panjnad system", "Major river of the Punjab network."),
    River("Ravi", "Himalayas", "Chenab", "Important eastern Punjab tributary."),
    River("Sutlej", "Tibetan Plateau", "Panjnad", "Eastern major tributary of the Indus system."),
    River("Kabul", "Hindu Kush region", "Indus near Attock", "Important western tributary."),
    River("Swat", "Hindu Kush", "Kabul River", "Important Khyber Pakhtunkhwa tributary.")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@Composable
fun App() {
    var tab by remember { mutableIntStateOf(0) }
    val labels = listOf("Overview", "Rivers", "Map", "Flood")
    Scaffold(
        topBar = { TopAppBar(title = { Text("Pakistan Rivers System", fontWeight = FontWeight.Bold) }) },
        bottomBar = {
            NavigationBar {
                labels.forEachIndexed { i, label ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Text(listOf("⌂", "≈", "⌖", "⚠")[i]) },
                        label = { Text(label) }
                    )
                }
            }
        }
    ) { pad ->
        when (tab) {
            0 -> Overview(Modifier.padding(pad))
            1 -> Rivers(Modifier.padding(pad))
            2 -> SystemMap(Modifier.padding(pad))
            else -> Flood(Modifier.padding(pad))
        }
    }
}

@Composable
fun Overview(modifier: Modifier) {
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.padding(18.dp)) {
                    Text("Pakistan Water Intelligence", style = MaterialTheme.typography.headlineSmall)
                    Spacer(Modifier.height(8.dp))
                    Text("Pakistan-focused platform for rivers, tributaries, terrain, water observations and flood analysis.")
                }
            }
        }
        item { Text("Core system", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        items(listOf(
            "River network" to "Rivers, tributaries, confluences and linked channels",
            "Topography" to "Elevation, valleys, slopes and flood-prone lowlands",
            "Water observation" to "Gauge data plus satellite-derived surface-water information",
            "Flood analysis" to "Rainfall, river state and inundation modelling"
        )) { (title, body) ->
            Card { Column(Modifier.padding(16.dp)) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp)); Text(body)
            }}
        }
    }
}

@Composable
fun Rivers(modifier: Modifier) {
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("Pakistan River Network", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text("Initial reference dataset; accurate GIS geometries and coordinates are planned for the next phase.")
        }
        items(rivers) { r ->
            Card { Column(Modifier.padding(16.dp)) {
                Text(r.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text("Source: ${r.source}")
                Text("Outlet / confluence: ${r.outlet}")
                Spacer(Modifier.height(6.dp))
                Text(r.description)
            }}
        }
    }
}

@Composable
fun SystemMap(modifier: Modifier) {
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("River System Map", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Phase 1 schematic. It will be replaced by geographic GIS layers.")
        Spacer(Modifier.height(16.dp))
        Card(Modifier.fillMaxWidth()) {
            Box(Modifier.fillMaxWidth().height(440.dp).padding(12.dp)
                .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(18.dp))) {
                Canvas(Modifier.fillMaxSize().padding(24.dp)) {
                    fun river(points: List<Offset>) {
                        val path = Path().apply {
                            moveTo(points.first().x, points.first().y)
                            points.drop(1).forEach { lineTo(it.x, it.y) }
                        }
                        drawPath(path, style = Stroke(width = 8f))
                    }
                    val w = size.width; val h = size.height
                    river(listOf(Offset(w*.60f,h*.08f),Offset(w*.57f,h*.25f),Offset(w*.53f,h*.43f),Offset(w*.48f,h*.64f),Offset(w*.42f,h*.84f)))
                    river(listOf(Offset(w*.30f,h*.22f),Offset(w*.38f,h*.35f),Offset(w*.50f,h*.50f)))
                    river(listOf(Offset(w*.78f,h*.20f),Offset(w*.67f,h*.37f),Offset(w*.56f,h*.48f)))
                    river(listOf(Offset(w*.18f,h*.35f),Offset(w*.34f,h*.47f),Offset(w*.49f,h*.56f)))
                    river(listOf(Offset(w*.84f,h*.48f),Offset(w*.68f,h*.57f),Offset(w*.50f,h*.65f)))
                }
                Text("INDUS BASIN\nSCHEMATIC", Modifier.align(Alignment.TopStart).padding(18.dp), fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun Flood(modifier: Modifier) {
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text("Flood Analysis", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text("Prepared for future rainfall, gauge, satellite-water and hydraulic-model integration.")
        }
        items(listOf(
            "River state" to "Gauge level/discharge and flood category",
            "Rainfall" to "Observed and forecast precipitation",
            "Terrain" to "Elevation, slope and drainage characteristics",
            "Surface water" to "Satellite-derived water extent/change",
            "Inundation" to "Modelled flood extent and affected lowlands"
        )) { (title, body) ->
            Card { Column(Modifier.padding(16.dp)) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(5.dp)); Text(body)
            }}
        }
        item { Button(onClick = {}) { Text("Data connection will be added") } }
    }
}
