# Pakistan Rivers System — Phase 1

Native Android app foundation using Kotlin + Jetpack Compose.

### Included
- Overview dashboard
- Initial Pakistan river reference list
- River-system schematic
- Flood-analysis module shell
- GitHub Actions Android build
- No Flutter
- No NDK
- No large offline GIS datasets

### Next phases
1. Accurate river GeoJSON + coordinates
2. Interactive GIS map
3. DEM/topography
4. Satellite surface-water layers
5. Rainfall and gauge data
6. Flood/inundation modelling
7. Historical analysis and decision-support tools
